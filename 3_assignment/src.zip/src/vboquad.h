#ifndef Quad_H
#define Quad_H

class Quad
{

private:
    unsigned int quadVAOHandle;

public:
    Quad();

    void render();
};

#endif // Quad_H
